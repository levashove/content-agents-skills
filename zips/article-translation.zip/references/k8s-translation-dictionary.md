---
name: k8s-translation-dictionary
updated: 2026-10-08
delivery: reference
description: |
  Словарь терминологии Kubernetes для перевода технических статей с английского
  на русский. Содержит: что переводится, что остаётся в оригинале, падежные
  формы и склонения, типовые ошибки. Подключается к article-translator,
  translation-editor и translation-verifier при переводе K8s-статей.

  Источники: CNCF Cloud Native Glossary (RU), Kubernetes Standardized Glossary,
  переводы Фланта на Хабре, методология «Альянса ПРО», devopsgu.ru.
activation:
  - "kubernetes"
  - "k8s"
  - "kubectl"
  - "pod"
  - "deployment"
  - "helm"
  - "cluster"
  - "container orchestration"
  - "istio"
  - "ingress"
  - "cni"
  - "operator"
  - "openshift"
  - "kubelet"
---

# K8s Translation Dictionary

Словарь для переводчиков технических статей по Kubernetes. **Не догма** — отражает консенсус русскоязычного K8s-сообщества (Флант, CNCF локализация, devopsgu.ru, Альянс ПРО) на 2026 год. Если автор оригинала использует устоявшийся в его команде вариант, и он не противоречит словарю — оставляй авторский.

## Принципы

1. **Имена ресурсов Kubernetes API — не переводятся.** `Pod`, `Deployment`, `Service`, `Ingress`, `StatefulSet` — это идентификаторы в API, как имена функций в коде. В тексте пишутся с заглавной, как в YAML.
2. **Русское слово по умолчанию, транслитерация — для частых терминов.** `pod` → «под», `node` → «узел» (в техтексте допустима «нода»). Используй в одном тексте **один** вариант, не смешивай «под» и `Pod`, «узел» и «нода».
3. **Сложные концепции — переводятся.** `Control Plane` → «управляющий слой», `Workload` → «рабочая нагрузка», `Self-Healing` → «самовосстановление».
4. **CLI-команды и компоненты-сервисы — оригинал.** `kubectl`, `kubelet`, `kube-proxy`, `etcd` — пишутся как в коде, не склоняются.
5. **Аббревиатуры — оригинал.** API, RBAC, CRD, CRI, CNI, CSI, HPA, VPA, PV, PVC. При первом упоминании допустимо раскрыть сокращение рядом с ним — «RBAC (Role-Based Access Control)»: это расшифровка аббревиатуры, а не толкование термина.
6. **При первом упоминании узкого термина — сноска переводчика, не скобки.** В тексте — `Sidecar[^1]`, `Taint[^2]`; в конце материала — `[^1]: Sidecar — вспомогательный контейнер в том же поде. — Прим. перев.`, `[^2]: Taint — метка на узле, запрещающая размещать на нём поды без соответствующего toleration. — Прим. перев.` Дальше — термин без сноски. Три исхода для любого термина: русское слово, оригинал, оригинал со сноской.

## Раздел 1. Базовые объекты Kubernetes API

| English | Русский | Комментарий |
|---------|---------|-------------|
| Pod | под / `Pod` | В нарративе — «под» (склоняется: пода, поду; мн.ч. — поды). Имя ресурса API — `Pod` с заглавной, как в YAML, не склоняется. Один вариант на текст |
| Node | узел / нода | «Узел» — официальный перевод CNCF; в техтексте допустима «нода». Один вариант на текст |
| Cluster | кластер | Склоняется: кластера, кластеру, кластером |
| Namespace | пространство имён / namespace | В командах и YAML — `namespace`; в нарративе — «пространство имён» |
| Container | контейнер | Базовый перевод, без вариантов |
| Image | образ | «Образ контейнера», не «имидж» |
| Container Image | образ контейнера | — |
| Registry | реестр | «Реестр образов» (container registry). `registry` — только в именах продуктов: Docker Registry |
| Object | объект (Kubernetes) | «Объекты Kubernetes», «K8s-объекты» |
| Resource | ресурс | «Ресурс Kubernetes», `apiResource` |
| Manifest | манифест / YAML-манифест | — |
| Label | метка | В нарративе — «метка»; в полях YAML — `labels`, `matchLabels`. Не дублировать оригиналом рядом с русским словом |
| Selector | селектор | «label selector» → «селектор меток» |
| Annotation | аннотация | — |

## Раздел 2. Workloads и контроллеры

| English | Русский | Комментарий |
|---------|---------|-------------|
| Deployment | Deployment | Объект API — не переводится, не склоняется. «Деплоймент» — разговорно, в статьях — `Deployment` |
| Deployment process (action) | развёртывание | Действие, а не объект API: «развёртывание приложения», «поэтапное развёртывание». «Деплой» — разговорный англицизм техтекста |
| ReplicaSet | ReplicaSet | — |
| StatefulSet | StatefulSet | — |
| DaemonSet | DaemonSet | — |
| Job | Job | Не переводить — конфликт с общим «работа» |
| CronJob | CronJob | — |
| ReplicationController | ReplicationController | Устаревший термин (deprecated) |
| Workload | рабочая нагрузка / workload | «K8s workloads» можно оставлять. В нарративе — «рабочая нагрузка» |
| Pod template | шаблон пода / pod template | — |
| Rollout | выкатка / rollout | «Выкатка обновления» — в практическом тексте; `rollout` — в командах: `kubectl rollout status` |
| Rollback | откат | «Откат к предыдущей версии»; глагол — «откатить». `rollback` — только в командах |
| Rolling update | поэтапное обновление / rolling update | В нарративе — «поэтапное обновление»; `RollingUpdate` — значение поля `strategy.type` |
| Canary deployment | канареечное развёртывание | Не «canary-деплой», не «канареечная выкатка» |
| Blue/Green deployment | blue/green-развёртывание | Цветовая пара остаётся латиницей, через дефис; не «сине-зелёное развёртывание» |

## Раздел 3. Сеть

| English | Русский | Комментарий |
|---------|---------|-------------|
| Service | Service | Не переводить — конфликт с общим «сервис». В YAML — `Service` |
| ClusterIP | ClusterIP | Тип Service |
| NodePort | NodePort | Тип Service |
| LoadBalancer | LoadBalancer | Тип Service |
| ExternalName | ExternalName | Тип Service |
| Headless Service | headless Service | Оригиналом; описательные варианты вроде «бесшапочный» не прижились |
| Ingress | Ingress | — |
| Ingress Controller | Ingress-контроллер | Через дефис, без «of» |
| Gateway API | Gateway API | — |
| `Gateway` (CRD Gateway API) | `Gateway` | Не путать с `Gateway` Istio (legacy CRD). В backtick |
| `GatewayClass` | `GatewayClass` | Шаблон контроллера в Gateway API |
| `HTTPRoute`, `GRPCRoute`, `TLSRoute`, `TCPRoute`, `UDPRoute` | как есть, в backtick | CRD Gateway API для маршрутов |
| `ReferenceGrant` | `ReferenceGrant` | CRD для cross-namespace разрешений |
| `BackendTrafficPolicy` / `SecurityPolicy` / `EnvoyPatchPolicy` | как есть, в backtick | Кастомные Policy-CRD Envoy Gateway |
| `KongPlugin` | `KongPlugin` | CRD Kong |
| `HTTPProxy` | `HTTPProxy` | Legacy CRD Contour |
| `AuthorizationPolicy` / `VirtualService` / `EnvoyFilter` | как есть, в backtick | CRD Istio. `VirtualService` deprecated в пользу Gateway API |
| `Ambient Mode` (Istio) | `Ambient Mode` / амбиент-режим | Архитектура Istio без sidecar. При первом упоминании — оригинал, далее допустим «амбиент-режим» |
| `Sidecar Mode` (Istio) | `Sidecar Mode` / sidecar-режим | Традиционная архитектура Istio. При первом упоминании — оригинал, далее допустим «sidecar-режим» |
| `Waypoint proxy` | `Waypoint proxy` / waypoint-прокси | L7-прокси на service account в Ambient. При первом упоминании — оригинал, далее допустим «waypoint-прокси» |
| `ztunnel` | `ztunnel` | L4-прокси на узле в Ambient (zero-trust tunnel). Не склонять |
| Имена ingress-/gateway-проектов | как есть, в backtick где это название продукта: `Envoy Gateway`, `NGINX Gateway Fabric`, `NGINX Plus`, `NGINX OSS` | См. devops-словарь |
| Имена контроллеров и продуктов | как есть, без backtick: Envoy, Contour, Gloo, Kong, Traefik, HAProxy, ingress-nginx, Pipy, OpenResty, Tetrate, Ambassador | — |
| `xDS` (protocol / server / stream) | `xDS` (xDS-протокол, xDS-сервер, xDS-поток, xDS-конфигурация) | Конфигурационный протокол Envoy |
| Policy attachment (паттерн Gateway API) | policy attachment | Латиницей; при первом упоминании — сноска переводчика: «Policy attachment — паттерн Gateway API для привязки политик к ресурсам. — Прим. перев.» |
| `listeners` (поле Gateway) | `listeners` / «слушатели» | В контексте поля — в backtick; в нарративе — «слушатели» |
| North-South / East-West traffic | north-south / east-west трафик | См. networking-словарь |
| Network Policy | Network Policy / сетевая политика | — |
| Service Mesh | Service Mesh / сервисная сетка | Чаще оставляют английский |
| Sidecar | sidecar / сайдкар | При первом упоминании — сноска переводчика: «Sidecar — вспомогательный контейнер в том же поде. — Прим. перев.» |
| CNI (Container Network Interface) | CNI | Аббревиатура; при первом упоминании — расшифровка |
| Calico, Cilium, Flannel, Weave | оригинал | Названия CNI-плагинов не переводятся |
| kube-proxy | kube-proxy | Компонент |
| CoreDNS | CoreDNS | Имя продукта |
| DNS | DNS | — |
| Endpoint | endpoint / эндпойнт / точка доступа | — |
| EndpointSlice | EndpointSlice | — |
| Topology-aware routing (TAR) | topology-aware routing | Функция Kubernetes; оригиналом, при первом упоминании — сноска переводчика. Описательное «topology-based routing» — «маршрутизация на основе топологии»; источник: перевод «Kubernetes Multi-Cluster DR with Linkerd & HAZL», 2026-10-07 |
| Exposure mode / to expose (a service) | режим публикации / публиковать (сервис) | Проверить: в нарративе встречается и «открыть доступ к сервису»; один вариант на текст; источник: перевод «Kubernetes Multi-Cluster DR with Linkerd & HAZL», 2026-10-07 |

## Раздел 4. Хранилище

| English | Русский | Комментарий |
|---------|---------|-------------|
| Volume | volume / том | Чаще «volume». «Том» — официальный перевод CNCF |
| PersistentVolume (PV) | PersistentVolume / PV | Не переводить — имя ресурса |
| PersistentVolumeClaim (PVC) | PersistentVolumeClaim / PVC | — |
| StorageClass | StorageClass | — |
| Provisioner | provisioner / провижионер | — |
| Reclaim Policy | reclaim policy / политика освобождения | — |
| CSI (Container Storage Interface) | CSI | Аббревиатура; при первом упоминании — расшифровка |
| Stateful / Stateless | stateful / stateless | Часто оставляют английский: «stateful-приложение», «stateless-сервис» |

## Раздел 5. Конфигурация и переменные

| English | Русский | Комментарий |
|---------|---------|-------------|
| Environment variable | переменная окружения | — |
| ConfigMap | ConfigMap | Имя ресурса API — не переводить |
| Secret | Secret | Имя ресурса API — не «секрет» в кавычках, а `Secret` |
| Resource quota | ResourceQuota / квота ресурсов | — |
| LimitRange | LimitRange | — |
| Requests / Limits | requests / limits | Не переводить — это поля YAML |
| QoS (Quality of Service) Class | QoS Class / класс QoS | Аббревиатура; при первом упоминании — расшифровка |

## Раздел 6. Безопасность и доступ

| English | Русский | Комментарий |
|---------|---------|-------------|
| RBAC (Role-Based Access Control) | RBAC | При первом упоминании — расшифровка |
| Role / ClusterRole | Role / ClusterRole | Имена ресурсов |
| RoleBinding / ClusterRoleBinding | RoleBinding / ClusterRoleBinding | — |
| ServiceAccount | ServiceAccount | — |
| Pod Security Standards (PSS) | Pod Security Standards / PSS | — |
| Pod Security Admission (PSA) | Pod Security Admission / PSA | — |
| Security Context | Security Context / контекст безопасности | — |
| Admission Controller | admission controller | Оригиналом, строчными; при первом упоминании — сноска переводчика: «Admission controller — компонент Kubernetes, проверяющий и изменяющий запросы к API до записи объекта. — Прим. перев.» |
| OPA (Open Policy Agent) | OPA | — |
| Gatekeeper | Gatekeeper | Имя продукта |
| Image Pull Secret | imagePullSecret | Поле YAML |

## Раздел 7. Управляющий слой (Control Plane)

| English | Русский | Комментарий |
|---------|---------|-------------|
| Control Plane | управляющий слой / Control Plane | Оба варианта приемлемы. «Управляющий слой» — официальный перевод CNCF |
| Data Plane | плоскость данных / Data Plane | — |
| kube-apiserver / API Server | API Server / kube-apiserver | Компонент. Не переводить |
| etcd | etcd | Имя продукта, не склоняется |
| kube-scheduler / Scheduler | Scheduler / планировщик | Чаще оставляют «Scheduler» |
| kube-controller-manager | kube-controller-manager / Controller Manager | — |
| cloud-controller-manager | cloud-controller-manager | — |
| kubelet | kubelet | Не переводить, не склоняется |
| Master node | мастер-нода / master-нода | Через дефис. Термин устаревает в пользу control plane node → «узел управляющего слоя» |
| Worker node | рабочий узел / рабочая нода / worker-нода | Согласуй с вариантом, выбранным для node в этом тексте |

## Раздел 8. CLI и инструменты

| English | Русский | Комментарий |
|---------|---------|-------------|
| kubectl | kubectl | Не переводить, не склоняется. «Команда kubectl», но не «kubectl-у» |
| kubeadm | kubeadm | — |
| minikube, kind, k3s, k3d, microk8s | оригинал | Названия дистрибутивов / runtime'ов |
| Helm | Helm | Имя продукта |
| Helm Chart | Helm Chart / чарт | «Чарт» — допустимо в нарративе. «Helm-чарт» через дефис |
| Helm Release | Helm Release / релиз | — |
| Helm Repository | Helm-репозиторий | — |
| Kustomize | Kustomize | — |
| ArgoCD | Argo CD / ArgoCD | Официально пишется «Argo CD» с пробелом |
| Flux | Flux | — |
| Tilt, Skaffold, Telepresence | оригинал | Инструменты разработки |

## Раздел 9. Расширения API

| English | Русский | Комментарий |
|---------|---------|-------------|
| CRD (Custom Resource Definition) | CRD | Аббревиатура; при первом упоминании — расшифровка |
| Custom Resource (CR) | Custom Resource / CR | — |
| Operator | Operator / оператор | «Оператор» — допустимо. В YAML — `Operator` |
| Operator pattern | паттерн «оператор» | — |
| Controller | контроллер | — |
| Webhook | webhook / вебхук | — |
| Admission Webhook | admission webhook | — |
| Validating / Mutating Webhook | Validating / Mutating Webhook | — |
| Aggregation Layer | Aggregation Layer / слой агрегации | — |
| API Group | группа API / API group | — |
| API Version | версия API | — |

## Раздел 10. Планирование подов и ресурсы узлов

| English | Русский | Комментарий |
|---------|---------|-------------|
| Scheduling | планирование | «Pod scheduling» → «планирование подов» |
| Affinity / Anti-Affinity | affinity / anti-affinity | Оригиналом; при первом упоминании — сноска переводчика: «Affinity — правила привязки подов к узлам или друг к другу. — Прим. перев.» |
| Node Affinity | node affinity | — |
| Pod Affinity | pod affinity | — |
| Taint | taint | Оригиналом; при первом упоминании — сноска переводчика: «Taint — метка на узле, запрещающая размещать на нём поды без соответствующего toleration. — Прим. перев.». Описательный вариант «метка отторжения» не устоялся |
| Toleration | toleration | Оригиналом, парный к taint; «толерантность» не используется |
| nodeSelector | nodeSelector | Поле YAML |
| Topology Spread Constraints | topology spread constraints / правила распределения по топологии | — |
| Eviction | вытеснение / eviction | — |
| Drain | drain / осушение узла | «Сделать `kubectl drain`», «осушить узел» |
| Cordon | cordon | «Сделать `kubectl cordon`», «запретить размещение новых подов на узле» |
| Preemption | preemption / вытеснение по приоритету | — |
| PriorityClass | PriorityClass | — |
| Probe (Liveness / Readiness / Startup) | Liveness/Readiness/Startup Probe / проверка работоспособности | При первом упоминании — сноска переводчика: «Probe — проверка состояния контейнера: liveness — жив ли, readiness — готов ли принимать трафик, startup — завершился ли запуск. — Прим. перев.» |

## Раздел 11. Масштабирование и автоматизация

| English | Русский | Комментарий |
|---------|---------|-------------|
| Scaling | масштабирование | — |
| Horizontal Pod Autoscaler (HPA) | HPA / горизонтальный автоскейлер | — |
| Vertical Pod Autoscaler (VPA) | VPA / вертикальный автоскейлер | — |
| Cluster Autoscaler | Cluster Autoscaler | — |
| Karpenter | Karpenter | Имя продукта |
| Autoscaling | автомасштабирование / автоскейлинг | Оба варианта используются. «Автоскейлинг» — частая калька |
| Replica | реплика | Склоняется: реплики, реплику |
| Replicas (field) | replicas | Поле YAML |

## Раздел 12. Мониторинг и наблюдаемость

| English | Русский | Комментарий |
|---------|---------|-------------|
| Observability | наблюдаемость / observability | Оба варианта приемлемы, один на текст. `observability` — допустимый англицизм в техтексте |
| Metrics | метрики | — |
| Logs | логи | — |
| Tracing | трассировка | «Distributed tracing» → «распределённая трассировка» |
| Prometheus | Prometheus | — |
| Grafana | Grafana | — |
| Loki, Tempo, Mimir | оригинал | Имена продуктов |
| OpenTelemetry (OTel) | OpenTelemetry / OTel | — |
| Jaeger | Jaeger | — |
| Alertmanager | Alertmanager | — |
| Dashboard | дашборд / панель | «Дашборд» — устоявшаяся транслитерация |
| SLO / SLA / SLI | SLO / SLA / SLI | Аббревиатуры |

## Раздел 13. Cloud Native концепции

| English | Русский | Комментарий |
|---------|---------|-------------|
| Cloud Native | Cloud Native / облачно-нативный | Чаще оставляют английский |
| Kubernetes-native | Kubernetes-native / нативный для Kubernetes | Термин знаком аудитории — не дублировать русским вариантом рядом: «Kubernetes-native операторы (нативные для Kubernetes)» — избыточно |
| Container Orchestration | оркестрация контейнеров | — |
| Microservices | микросервисы | — |
| Serverless | serverless / бессерверный | Чаще «serverless»: «serverless-функции»; в нарративе допустимо «бессерверные вычисления» |
| Function-as-a-Service (FaaS) | FaaS | — |
| Multi-tenancy | мультитенантность / multi-tenancy | — |
| Multi-cluster | мультикластерный / multi-cluster | «Мультикластерная установка»; слитно, без дефиса |
| Hybrid Cloud | гибридное облако | — |
| Edge Computing | edge computing / периферийные вычисления | — |
| Immutable Infrastructure | неизменяемая инфраструктура | — |
| Infrastructure as Code (IaC) | инфраструктура как код / IaC | — |
| GitOps | GitOps | Не переводить |
| Self-Healing | самовосстановление | — |
| Declarative | декларативный | — |
| Imperative | императивный | — |
| Reconciliation Loop | reconciliation loop / цикл согласования | — |

### ИИ-агенты на Kubernetes (2026)

Продукты и сущности агентного слоя. Все — латиницей, не транслитерировать
(«актор», «воркер»), не склонять, множественное число английским `-s`:
`Actors`, `Workers`, `WorkerPools`, `ActorTemplates`. Исходная статья —
InfoQ «Pods as Workers, Not Agents».

| English | Русский | Комментарий |
|---------|---------|-------------|
| kagent | kagent | Не переводить. CNCF-проект (Solo.io): запуск и оркестрация ИИ-агентов как нативных ресурсов Kubernetes. **Всегда строчными**, включая начало предложения — если по пунктуации нельзя, перестроить фразу. Узкий термин: при первом упоминании — сноска |
| Agent Substrate | Agent Substrate | Не переводить. Control plane Google поверх Kubernetes: планирует логические агенты (Actor) на пул исполнителей (Worker). Узкий термин: при первом упоминании — сноска |
| Agent Sandbox | Agent Sandbox | Не переводить. Проект экосистемы Kubernetes (`sigs.k8s.io`): изолированная песочница для выполнения кода ИИ-агентов. Узкий термин: при первом упоминании — сноска. Полное имя «Kubernetes Agent Sandbox project» — при первом упоминании, далее сокращать |
| Actor (Agent Substrate) | Actor | Не переводить и не транслитерировать. Логический ИИ-агент, планируется на Worker. Не путать с моделью акторов и с `Actor` из Swift Concurrency (mobile-словарь, там → «актор») |
| Worker (Agent Substrate) | Worker | Не переводить. Единица-исполнитель, 1:1 с Pod. **Не путать с Worker node** — это «рабочий узел / worker-нода» (раздел 7). В одном абзаце держать разграничение явно |
| WorkerPool | `WorkerPool` | Ресурс API Agent Substrate, группа Worker; аналог NodePool. В оригинале — в backtick'ах, сохранять моноширинный формат, не склонять |
| ActorTemplate | `ActorTemplate` | Ресурс API Agent Substrate, декларативное описание Actor; аналог спецификации Pod. В оригинале — в backtick'ах, сохранять формат, не склонять |
| NodePool | NodePool | Оригиналом, сноска не нужна: устоявшийся термин managed-Kubernetes у облачных провайдеров; в русских текстах также «пул узлов» |

## Раздел 14. Глаголы и действия

| English | Русский | Комментарий |
|---------|---------|-------------|
| to deploy | развернуть / задеплоить | «Развернуть приложение». «Задеплоить» — разговорно, в статьях лучше «развернуть» |
| to apply (kubectl apply) | применить | «Применить манифест» |
| to scale | масштабировать | — |
| to scale up / down | масштабировать вверх / вниз | — |
| to roll out | выкатить | «Выкатить обновление» |
| to roll back | откатить | — |
| to provision | выделить / подготовить | «Выделить узлы под кластер»; provisioning → «выделение ресурсов» |
| to evict | вытеснить (под) | — |
| to schedule | разместить / запланировать (под) | — |
| to spin up | поднять / запустить | «Поднять кластер» |
| to tear down | свернуть / удалить | — |
| to expose | пробросить / открыть наружу | «Expose Service» → «открыть Service наружу» |
| to label | пометить / навесить метку | — |
| to taint a node | поставить taint на узел | — |

## Раздел 15. Падежные формы (для частых терминов)

### Pod → под

| Падеж | Форма |
|-------|-------|
| Именительный | под |
| Родительный | пода |
| Дательный | поду |
| Винительный | под |
| Творительный | подом |
| Предложный | поде |
| Мн.ч. им. | поды |
| Мн.ч. род. | подов |

Если используешь `Pod` без транслитерации — не склоняй: «создать Pod», «удалить Pod», «у этого Pod», не «Pod'а».

### Node → узел / нода

Канонический вариант — «узел»; «нода» допустима в техтексте. В одном тексте — один вариант.

| Форма | Узел | Нода |
|-------|------|------|
| Им. ед. | узел | нода |
| Род. ед. | узла | ноды |
| Дат. ед. | узлу | ноде |
| Вин. ед. | узел | ноду |
| Твор. ед. | узлом | нодой |
| Предл. ед. | об узле | о ноде |
| Мн.ч. им. | узлы | ноды |
| Мн.ч. род. | узлов | нод |

### Cluster → кластер

Склоняется как обычное существительное мужского рода: кластер, кластера, кластеру, кластером, о кластере.

### Helm Chart → чарт

«Чарт», «чарта», «чарту», «чартом». Мн.ч.: «чарты», «чартов».

### Kubernetes / K8s

**Не склоняется:** «в Kubernetes», «для Kubernetes», «с Kubernetes», но НЕ «в Кубернетесе». Это имя собственное продукта.

`K8s` — тоже не склоняется. Род — мужской: «Kubernetes запустил», «K8s применил».

### kubectl, kubelet, etcd

**Не склоняются и не имеют рода.** Всегда строчная буква, как в коде. «Запустить kubectl», «команда kubectl», но не «kubectl'ом», не «через kubectl-у».

## Раздел 16. Типовые ошибки переводчика K8s-статей

### 1. Перевод имён ресурсов

```
✗ «Создайте Развертывание»
✓ «Создайте Deployment»

✗ «Откатить службу»
✓ «Откатить Service» / «откатить сервис» (если имеется в виду микросервис, не K8s Service)
```

### 2. Несогласованность транслитерации

В одном тексте — один вариант. Не смешивай:

```
✗ В кластере 5 подов. Pod'ы запускаются на 3 нодах. Поды переходят в Running.
✓ В кластере 5 подов. Поды запускаются на 3 нодах. Поды переходят в Running.
```

### 3. Склонение несклоняемых

```
✗ «Запустить kubectl'ом»  →  ✓ «Запустить с помощью kubectl» / «через kubectl»
✗ «У kubelet'а есть...»    →  ✓ «У kubelet есть...» / «Kubelet имеет...»
✗ «В Кубернетесе»           →  ✓ «В Kubernetes»
```

### 4. Перевод полей YAML

Имена полей в YAML/JSON — **никогда** не переводи:

```yaml
spec:
  replicas: 3        # НЕ «реплики: 3»
  selector:          # НЕ «селектор:»
    matchLabels:     # НЕ «совпадающиеМетки:»
      app: nginx
```

Это правило относится и к комментариям в коде — переводи **только** комментарии, не сами поля.

### 5. Калька «является»

```
✗ «Pod является минимальной единицей»
✓ «Pod — минимальная единица»
```

### 6. Калька «позволяет»

```
✗ «HPA позволяет масштабировать поды»
✓ «HPA масштабирует поды» / «С HPA можно масштабировать поды»
```

### 7. Английский порядок слов

```
✗ «Это позволяет вам легко управлять кластером»  (калька с «allows you to easily»)
✓ «Кластером легко управлять» / «Вы легко управляете кластером»
```

### 8. Пассив без необходимости

```
✗ «Поды могут быть запущены на разных нодах»
✓ «Поды можно запускать на разных нодах» / «Kubernetes запускает поды на разных нодах»
```

### 9. Двойное название одного объекта

```
✗ «Service, или сервис, или служба, обеспечивает...»
✓ Выбери один вариант. В технических статьях обычно — `Service`.
```

### 10. Перевод устоявшихся английских составных

```
✗ «контроллер реплик» (для ReplicaSet)
✓ «ReplicaSet» — имя ресурса
```

## Раздел 17. Чек-лист переводчика K8s-статьи

Перед сдачей литерального перевода пройди по чеклисту:

- [ ] **Имена ресурсов API (Pod, Deployment, Service, Ingress, и т.д.)** — не переведены, написаны как в оригинале
- [ ] **Поля YAML** — не переведены (replicas, selector, matchLabels, spec, status и т.д.)
- [ ] **Команды CLI** — не изменены (`kubectl apply`, `helm install`, `kubectl get pods`)
- [ ] **kubectl, kubelet, etcd, kube-proxy** — везде строчными, не склоняются
- [ ] **Kubernetes / K8s** — не склоняются («в Kubernetes», не «в Кубернетесе»)
- [ ] **Транслитерация согласована** — в тексте один вариант для каждого термина (либо «под», либо `Pod`, не смесь)
- [ ] **Аббревиатуры (RBAC, CRD, HPA, VPA, PV, PVC, CRI, CNI, CSI)** — оригинал, расшифровка при первом упоминании
- [ ] **Узкие термины (sidecar, taint, admission controller)** — оригинал со сноской переводчика «— Прим. перев.» при первом упоминании, без пояснений в тексте
- [ ] **Названия продуктов экосистемы** (Helm, Prometheus, Grafana, Calico, Cilium, Istio, ArgoCD) — оригинал
- [ ] **Названия дистрибутивов** (minikube, k3s, kind, OpenShift) — оригинал
- [ ] **Калек избегли** — нет «является», «позволяет», «осуществляет», «производит»
- [ ] **Кавычки** — «ёлочки», внутри — „лапки“
- [ ] **Числа** — `10 000` (пробел), `3,14` (запятая), `5 ГБ`, `100 мс`
- [ ] **Атрибуция оригинала** — в конце есть блок «Оригинал: {Title} — {Author}, {date}» + URL

## Раздел 18. Когда термин имеет несколько устоявшихся переводов

Если в русскоязычном сообществе K8s нет единого варианта (например, `node` → «узел» / «нода», `observability` → «наблюдаемость» / `observability`), действуй по приоритету:

1. **Смотри на оригинал.** Если автор сам в английском тексте использует жаргонизм («k8s» вместо «Kubernetes»), сохраняй такой же уровень формальности в переводе.
2. **Смотри на площадку.** Хабр + Флант — чаще «нода», «под», «observability». Документация и формальные тексты — «узел», `Pod`, «наблюдаемость».
3. **Если переводишь в первый раз — бери канонический (первый) вариант словаря:** «узел», «под», «наблюдаемость». «Нода» и `observability` — осознанный выбор под площадку, не дефолт.
4. **В одном тексте — один вариант.** Это правило важнее любого «правильного» выбора.

## Раздел 19. Что делать с новыми терминами

Если в статье встречается термин, которого нет в этом словаре:

1. **Проверь CNCF Glossary RU** — https://glossary.cncf.io/ru/
2. **Проверь Kubernetes Docs RU** — https://kubernetes.io/ru/docs/
3. **Поищи в публикациях Фланта на Хабре** — https://habr.com/ru/companies/flant/
4. Если нигде нет — оставь **в оригинале**; если термин узкий, при первом упоминании дай сноску переводчика: `Термин[^N]` + `[^N]: Термин — что это. — Прим. перев.` Помета «устоявшегося перевода нет» — в отчёт проверяльщику, не в текст.
5. Не придумывай свой перевод — это вносит непоследовательность в экосистему.

Все новые термины, которые встретились в работе, проверяльщик (`translation-verifier`) может предложить добавить в словарь. Решение о добавлении — за оркестратором и редактором.

## Источники

Словарь составлен на основе следующих авторитетных русскоязычных ресурсов K8s-сообщества:

| Источник | Назначение |
|----------|-----------|
| CNCF Cloud Native Glossary (RU) — https://glossary.cncf.io/ru/ | Официальный глоссарий CNCF на русском; локализация ведётся коллективно через GitHub |
| Kubernetes Standardized Glossary — https://kubernetes.io/docs/reference/glossary/ | Официальный глоссарий проекта Kubernetes; русская локализация в kubernetes/website |
| Документация Kubernetes на русском — https://kubernetes.io/ru/docs/ | Локализация ведётся коллективно |
| Флант на Хабре — https://habr.com/ru/companies/flant/ | Основной русский локализатор K8s-документации; устоявшиеся переводы |
| Альянс ПРО — методология для ИТ-переводчиков — https://tran.su/ | Методология ИТ-перевода: выбор между русским термином и оригиналом для составных понятий |
| devopsgu.ru/glossary/glossary-kubernetes/ | Практический глоссарий с переводами и пояснениями |

Версия словаря: **2026-10-08**. Обновляется по мере появления новых терминов и устоявшихся переводов.

## Дополнения от 2026-09-24

| English | Русский | Комментарий |
|---------|---------|-------------|
| Node pool | пул узлов | Группа узлов с одинаковой конфигурацией (AKS, GKE, managed-кластеры); брифинг 2026-09-24, сигналы: Хабр без пояснения |
| Node selector (в нарративе) | селектор узлов | В YAML — поле `nodeSelector`; брифинг 2026-09-24, сигналы: kubernetes.io/ru, Хабр |
| secretKeyRef | secretKeyRef | Поле YAML (ссылка на ключ Secret в `env`), не переводится; брифинг 2026-09-24 |

## Дополнения от 2026-10-08

Из терминологического брифинга «2026-08-24-how-to-pretty-print-kubernetes-yaml-as-kyaml» (внутренний материал системы, в эту выгрузку не входит) (KYAML, KEP 5295, SIG CLI); перенесены только термины с `confidence: high`.

| English | Русский | Комментарий |
|---------|---------|-------------|
| KYAML | KYAML | Строгое подмножество YAML для манифестов Kubernetes (KEP 5295, `kubectl -o kyaml`, 1.34+); имя формата — чистый оригинал, не транслитерируется и не склоняется («в KYAML», «файл KYAML»); брифинг 2026-08-24, сигналы: Хабр/Флант (обзор K8s 1.34) |
| kuberc | kuberc | Файл конфигурации kubectl со значениями по умолчанию для команд и флагов; оригинал, не склоняется; при первом упоминании в прозе — сноска с пояснением; брифинг 2026-08-24, сигналы: kubernetes.io/docs/reference/kubectl/kuberc, ру-источников нет |
| yamlfmt | yamlfmt | Имя инструмента, оригинал; два разных инструмента с одним именем — `sigs.k8s.io/yaml/yamlfmt` (Kubernetes) и `github.com/google/yamlfmt` (Google), принадлежность в тексте сохранять; брифинг 2026-08-24 |
| KEP (Kubernetes Enhancement Proposal) | KEP | Формальное предложение по развитию Kubernetes; аббревиатура — оригинал («KEP 5295»), при первом упоминании в прозе — сноска с расшифровкой и сутью; брифинг 2026-08-24, сигналы: Хабр/Флант в заголовках обзоров релизов |
| SIG CLI (Special Interest Group) | SIG CLI | Рабочая группа сообщества Kubernetes по инструментам командной строки (kubectl); оригинал, расшифровка — в сноске при первом упоминании; брифинг 2026-08-24, сигналы: github.com/kubernetes/community |
| Type coercion (silent type coercion) | неявное приведение типов | «Silent» переводится прилагательным внутри термина, не «тихое»; брифинг 2026-08-24, сигналы: Хабр (ITSumma, «YAML из Ада»), tproger, 1cloud |
| Whitespace sensitivity | чувствительность к отступам | Про YAML; вариант «к пробелам» допустим, в одном тексте — один; брифинг 2026-08-24, сигналы: Хабр/ITSumma, tproger, 1cloud |
| Dialect / strict subset (YAML) | диалект / строгое подмножество | Общеязыковые слова, прямой эквивалент без пояснения; брифинг 2026-08-24 |
| Templating (Helm) | шаблонизация | «Helm-шаблонизация», «шаблонизация чарта»; брифинг 2026-08-24, сигналы: Хабр/Флант в заголовках |

Не внесено: `pre-commit hook` → «pre-commit хук» уже есть в `devops-translation-dictionary` (раздел Git/VCS); термины с `confidence: medium` (flow/block style, trailing comma, pretty-print, mapping/struct, «Norway Bug») остаются решением брифинга и в словарь не идут.
